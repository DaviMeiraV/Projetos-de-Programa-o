<?php
// Defina o login e senha padrão
$loginPadrao = "usuario";
$senhaPadrao = "senha123";

session_start();

// Verifica se os dados de login foram enviados via POST
if (isset($_POST['login']) && isset($_POST['senha'])) {
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    // Verifica se as credenciais estão corretas
    if ($login === $loginPadrao && $senha === $senhaPadrao) {
        // Define a variável de sessão "logou" como 1
        $_SESSION['logou'] = 1;
        header("Location: area_restrita.php"); // Redireciona para a área restrita
        exit();
    } else {
        echo "Dados de login incorretos. Por favor, tente novamente.";
    }
}
?>
<?php
session_start();

// Verifica se o usuário está logado (se a variável de sessão "logou" existe e é igual a 1)
if (!isset($_SESSION['logou']) || $_SESSION['logou'] !== 1) {
    header("Location: index.html"); // Redireciona para a página de login
    exit();
}
?>

<?php
session_start();

// Verifica se o usuário está logado (se a variável de sessão "logou" existe e é igual a 1)
if (!isset($_SESSION['logou']) || $_SESSION['logou'] !== 1) {
    header("Location: index.html"); // Redireciona para a página de login
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área Restrita</title>
</head>
<body>
    <h1>Bem-vindo à Área Restrita</h1>
    <p>Aqui está uma foto de interesse:</p>
    <img src="sua_foto.jpg" alt="Sua Foto">
    <br><br>
    <a href="logout.php">Sair</a>
</body>
</html>

?>
<?php
session_start();

// Destroi a sessão (desloga o usuário)
session_destroy();

header("Location: index.html"); // Redireciona para a página de login
exit();
?>


